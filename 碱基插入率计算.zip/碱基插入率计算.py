def parse_gene_positions(filename):
    gene_positions = {}
    with open(filename, 'r') as file:
        for line in file:
            if line.startswith('#'):
                continue
            data = line.strip().split('\t')
            gene_id = data[8].split('"')[1]
            start = int(data[3])
            end = int(data[4])
            gene_positions[gene_id] = (start, end)
    return gene_positions

def assign_gene_id(gene_positions, position):
    for gene_id, (start, end) in gene_positions.items():
        if start <= position <= end:
            return gene_id
    return None

def process_tn_file(tn_filename, gene_positions, output_filename):
    with open(tn_filename, 'r') as tn_file:
        with open(output_filename, 'w') as output_file:
            for line in tn_file:
                data = line.strip().split('\t')
                position = int(data[0])
                total_insertions = int(data[3])
                gene_id = assign_gene_id(gene_positions, position)
                if gene_id:
                    result_line = f"{gene_id}\t{total_insertions}\n"
                    output_file.write(result_line)
                    print("Processed:", result_line.strip())
    print("Done. Result written to", output_filename)


if __name__ == "__main__":
    gene_positions = parse_gene_positions("EIB202_deletionplasmid_genomic.txt")
    process_tn_file("tn.txt", gene_positions, "result.txt")
    print("Done. Result written to result.txt")
