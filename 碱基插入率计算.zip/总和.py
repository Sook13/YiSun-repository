def process_result(input_file, output_file):
    gene_dict = {}
    
    # 读取 result.txt 文件
    with open(input_file, 'r') as f:
        for line in f:
            gene_id, count = line.strip().split('\t')
            gene_id = gene_id.strip()
            count = int(count.strip())
            if gene_id in gene_dict:
                gene_dict[gene_id] += count
            else:
                gene_dict[gene_id] = count
    
    # 将结果写入 result_charu.txt 文件
    with open(output_file, 'w') as f:
        for gene_id, count in gene_dict.items():
            f.write(f"{gene_id}\t{count}\n")

if __name__ == "__main__":
    process_result("result.txt", "result_charu.txt")
