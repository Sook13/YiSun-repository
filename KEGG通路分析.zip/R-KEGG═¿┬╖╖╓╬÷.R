# 导入所需包
library(clusterProfiler)
library(readxl)

# 读取Excel文件
up_data <- readxl::read_excel("上调.xlsx")
down_data <- readxl::read_excel("下调.xlsx")

# 提取基因ID列并转换为向量
gene_up <- up_data$GeneID
gene_down <- down_data$GeneID
gene_diff <- c(gene_up,gene_down)

# 如果您的所有基因信息也保存在Excel文件中，您可以使用类似的方法提取它们
# gene_all <- all_data$ENTREZID

# 富集分析
kk.up <- enrichKEGG(gene = gene_up,
                    organism = 'etr',
                    # 如果有全局基因集，可以添加 universe 参数
                    # universe = gene_all,
                    pvalueCutoff = 0.9,
                    qvalueCutoff = 0.9)

kk.down <- enrichKEGG(gene = gene_down,
                      organism = 'etr',
                      # 如果有全局基因集，可以添加 universe 参数
                      # universe = gene_all,
                      pvalueCutoff = 0.9,
                      qvalueCutoff = 0.9)

# 注意：gene_diff 已经包含了 gene_up 和 gene_down 的并集
kk.diff <- enrichKEGG(gene = gene_diff,
                      organism = 'etr',
                      pvalueCutoff = 0.9)

# 导入所需包
library(openxlsx)

# 将富集分析结果提取到数据框中
kegg_diff_dt <- as.data.frame(kk.diff@result)

# 指定要保存的文件路径和文件名
output_file <- "kegg_diff_results.xlsx"

# 使用 write.xlsx() 函数保存数据框为xlsx表格
write.xlsx(kegg_diff_dt, file = output_file, rowNames = FALSE)

# 打印信息确认保存成功
print(paste("富集分析结果已保存为", output_file))

#从下调基因的富集分析结果kk.down中筛选出p-value小于0.05的结果，并将结果添加一个名为group的列，赋值为-1，用于标识下调基因。
down_kegg <- kk.down@result %>%
  filter(pvalue<0.05) %>%
  mutate(group=-1)

#从上调基因的富集分析结果kk.up中筛选出p-value小于0.05的结果，并将结果添加一个名为group的列，赋值为1，用于标识上调基因
up_kegg <- kk.up@result %>%
  filter(pvalue<0.05) %>%
  mutate(group=1)