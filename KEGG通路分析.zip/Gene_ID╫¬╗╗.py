import pandas as pd
from Bio import Entrez

# 设置你的email地址
Entrez.email = "2283118171@qq.com"

# 从Excel文件中读取第一列（Gene ID）
def read_protein_ids_from_excel(file_path):
    try:
        # 使用pandas读取Excel文件
        df = pd.read_excel(file_path, usecols=[0])
        # 获取第一列的蛋白ID
        protein_ids = df.iloc[:, 0].tolist()
        return protein_ids
    except Exception as e:
        print(f"Error occurred while reading Excel file: {e}")
        return []

# 定义一个函数来获取NCBI Gene ID
def get_gene_id(protein_id):
    try:
        # 使用Entrez的esearch函数搜索NCBI Gene数据库中与蛋白ID相关联的记录
        handle = Entrez.esearch(db="gene", term=protein_id)
        record = Entrez.read(handle)
        # 返回搜索到的Gene ID（如果有的话）
        return record["IdList"][0] if record["IdList"] else None
    except Exception as e:
        print(f"Error occurred while retrieving Gene ID for {protein_id}: {e}")
        return None

# 输入Excel文件路径
excel_file_path = input("Enter the path to the Excel file: ")

# 从Excel文件中读取蛋白ID列表
protein_ids = read_protein_ids_from_excel(excel_file_path)

# 创建一个空的DataFrame来存储结果
result_df = pd.DataFrame(columns=["Protein ID", "Gene ID"])

# 循环处理每个蛋白ID，并将结果存储在DataFrame中
for protein_id in protein_ids:
    gene_id = get_gene_id(protein_id)
    # 将每个结果作为DataFrame对象存储起来
    temp_df = pd.DataFrame({"Protein ID": [protein_id], "Gene ID": [gene_id]})
    result_df = pd.concat([result_df, temp_df], ignore_index=True)

# 将结果DataFrame保存为Excel文件
output_file_path = input("Enter the path to save the output Excel file: ")
result_df.to_excel(output_file_path, index=False)

print("Results saved successfully.")
